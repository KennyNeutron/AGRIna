// src/app/(app)/dashboard/page.tsx
export default function DashboardPage() {
  return (
    <div className="min-h-[100dvh]">
      <header className="sticky top-0 z-10 border-b border-[color:var(--color-line)] bg-white/80 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-screen-2xl items-center px-6">
          <h1 className="text-lg font-semibold text-zinc-700">Dashboard</h1>
          <p className="ml-3 text-sm text-zinc-500">
            Overview of all your devices and recent activity
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-screen-2xl px-6 py-6">
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          <div className="rounded-xl border border-[color:var(--color-line)] bg-white p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-zinc-700">
              Devices Online
            </h3>
            <p className="mt-2 text-3xl font-bold text-zinc-800">12</p>
            <p className="mt-1 text-xs text-zinc-500">Across 4 locations</p>
          </div>

          <div className="rounded-xl border border-[color:var(--color-line)] bg-white p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-zinc-700">
              Active Alerts
            </h3>
            <p className="mt-2 text-3xl font-bold text-zinc-800">3</p>
            <p className="mt-1 text-xs text-zinc-500">
              Moisture and pH thresholds
            </p>
          </div>

          <div className="rounded-xl border border-[color:var(--color-line)] bg-white p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-zinc-700">Latest Sync</h3>
            <p className="mt-2 text-3xl font-bold text-zinc-800">2m ago</p>
            <p className="mt-1 text-xs text-zinc-500">All collectors healthy</p>
          </div>
        </div>

        <div className="mt-6 rounded-xl border border-[color:var(--color-line)] bg-white p-6 shadow-sm">
          <h3 className="text-sm font-semibold text-zinc-700">
            Recent Activity
          </h3>
          <ul className="mt-3 space-y-2 text-sm text-zinc-600">
            <li>Device NDMC-01 reported new soil moisture reading</li>
            <li>Calibration completed for pH probe on Site-B</li>
            <li>Exported CSV for Week 12 readings</li>
          </ul>
        </div>
      </main>
    </div>
  );
}
