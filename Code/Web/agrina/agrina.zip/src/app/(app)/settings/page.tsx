// src/app/(app)/settings/page.tsx
export default function SettingsPage() {
  return (
    <div className="min-h-[100dvh]">
      <header className="sticky top-0 z-10 border-b border-[color:var(--color-line)] bg-white/80 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-screen-2xl items-center px-6">
          <h1 className="text-lg font-semibold text-zinc-700">Settings</h1>
          <p className="ml-3 text-sm text-zinc-500">
            Profile, notifications, and system preferences
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-screen-2xl px-6 py-6">
        <div className="rounded-xl border border-[color:var(--color-line)] bg-white p-6 shadow-sm">
          Account details and preferences go here.
        </div>
      </main>
    </div>
  );
}
