// src/app/login/actions.ts
"use server";

import { redirect } from "next/navigation";
import { createSupabaseAction } from "@/lib/supabase/server";

export async function signInAction(_: any, formData: FormData) {
  const email = String(formData.get("email") || "").trim();
  const password = String(formData.get("password") || "");

  const supabase = await createSupabaseAction();
  const { error } = await supabase.auth.signInWithPassword({ email, password });

  if (error) {
    return { ok: false, message: error.message };
  }
  redirect("/dashboard");
}

export async function signUpAction(_: any, formData: FormData) {
  const fullName = String(formData.get("name") || "").trim();
  const email = String(formData.get("email") || "").trim();
  const password = String(formData.get("password") || "");

  const supabase = await createSupabaseAction();
  const { error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { full_name: fullName },
      emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL || ""}/login`,
    },
  });

  if (error) {
    return { ok: false, message: error.message };
  }
  return {
    ok: true,
    message: "Check your email to confirm your account, then sign in.",
  };
}

export async function signOutAction() {
  const supabase = await createSupabaseAction();
  await supabase.auth.signOut();
  redirect("/login");
}
